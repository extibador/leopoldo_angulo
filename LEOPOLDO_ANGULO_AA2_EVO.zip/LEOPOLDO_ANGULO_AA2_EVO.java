/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package leopoldo_angulo_aa2_evo;

/**
 *
 * @author lizalda
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class LEOPOLDO_ANGULO_AA2_EVO {

    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String usuario = "root";
        String password = "";
        String url = "jdbc:mysql://localhost:3306/task";
        Connection conexion;
        Statement  statement;
        ResultSet rs;  

        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LEOPOLDO_ANGULO_AA2_EVO.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        try {
            conexion = DriverManager.getConnection(url,usuario,password);
            statement = conexion.createStatement();
            statement.executeUpdate("INSERT INTO USUARIOS(NOMBRE,email,contrasena,rol) VALUE('LEOPOLDO','lizalda@','123','empleado')");
            rs = statement.executeQuery("SELECT * FROM USUARIOs");
            rs.next();
            do{
               System.out.println(rs.getInt("id")+ ":"+rs.getString("nombre")); 
            }while(rs.next());
            
        } catch (SQLException ex) {
            Logger.getLogger(LEOPOLDO_ANGULO_AA2_EVO.class.getName()).log(Level.SEVERE, null, ex);
        }
  
    }
    
}
